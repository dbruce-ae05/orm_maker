# ORM Maker

ORM Maker makes an Object Relational Model from a comma separated values (csv) file - see the example.csv file.

# Supported ORMs
- [ ] SQL Alchemy
- [ ] SQLModel

